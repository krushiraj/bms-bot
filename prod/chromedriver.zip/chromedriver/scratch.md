link pattern = in.bookmyshow.com/{location[hyderabad/banglore/delhi]}/{type[movies/show/concert]}/{lang[telugu/hindi]}

location, movie name, language, format should be similar to one provided in bms
Theatre name should not contain any punctuation marks

#btnPopupAccept

#pop\_{num}

Empty seats will have id attribute where as occupied won't have any id

all together? if no what can be max split? x no of seats together

exclude rows? alphabet or top or bottom - left and right padding

select m ticket or box office pick up

click id="prePay", enter email and mobile number and click continue "dContinueContactSec"

payment type credit/debit/upi - dTUPI/dTDCC

card
txtCardNo
txtCardName
txtExpMonth
txtExpYear
txtCVV

UPI
txtMobileId
